console.log('Node running...');

const express = require('express');
const bodyParser = require('body-parser');
const app = express();
var mqtt = require('mqtt');
var client = mqtt.connect("mqtt://test.mosquitto.org", { clientId: "mqttjs01" });
var globalmsg;
var randomDataLoop;

//checking connection
client.on("connect", function () {
  console.log("MQTT Broker connected " + client.connected);
});

//handle errors
client.on("error", function (error) {
  console.log("Can't connect MQTT Broker " + error);
  process.exit(1)
});

// Subscribing topic
client.subscribe('topic', { qos: 0 }); 

//handle incoming messages
client.on('message', function (topic, message) {
  globalmsg = message.toString();
  console.log("Message is " + message.toString());
});

// method used from Post API to send message
function sendMessage(index, startBit) {
  if (startBit)
    clearInterval(randomDataLoop);
  else {
    randomData = {
      "S.No": index ,
      "Timestamp": new Date(+(new Date()) - Math.floor(Math.random() * 10000000000)) ,
      "CurrentValue": (Math.random() * (0.120 - 0.0200) + 0.0200).toFixed(3)
    }
    client.publish('topic', JSON.stringify(randomData));
  }
};


// Make sure you place body-parser before your CRUD handlers!
app.use(bodyParser.urlencoded({ extended: true }));

// defining port
app.listen(3000, function () {
  console.log('listening on 3000')
});

// API used to get data
app.get('/getData', (req, res) => {
  if (client.connected) {
    res.status(200).send({ "status": "RUNNING", "topic": globalmsg });
  }
  else {
    res.status(200).send({ "status": "STOPPED" });
  }
});

// API used to start and stop random data on MQTT
app.post('/addData', (req, res) => {
  clearInterval(randomDataLoop);
  console.log(req.body, 'reqBody');

  // When user inputs "start", it start sending random data
  if (req.body.mode == "start") {
    //Checking if the connection is stopped then re-connect
    if (!client.connected) {
      client.reconnect();
    }

    setTimeout(() => {
      var i = 0;
      randomDataLoop = setInterval(() => {
        sendMessage(i++, false);
      }, 3000);
    }, 1000);
    res.status(200).send("Start Message sent to MQTT Broker");
  }

  // When user inputs "stop", it stop sending random data and MQTT server also
  if (req.body.mode == "stop") {
    sendMessage(0, true)
    client.end();
    setTimeout(() => {
      console.log(client.connected, 'MQTT Broker stopped successfully.');
    }, 3000);
    res.status(200).send("Stop Message sent to MQTT Broker");
  }

})