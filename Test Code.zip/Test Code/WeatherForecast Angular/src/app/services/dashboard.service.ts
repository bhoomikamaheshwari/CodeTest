import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';

// API base path
const API_URL = environment.apiUrl;
const API_KEY = environment.apiKey;

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http: HttpClient) { }

  // Get API for Weather By City
  getWeatherByCity(cityName: any): Observable<any> {
    const url = API_URL + 'weather?q=' + cityName + '&appid=' + API_KEY;
    return this.http.get<any>(url)
      .pipe(
        tap(_ => this.log('fetched Weather details')),
        catchError(this.handleError<any>('getWeatherByCity'))
      );
  }
  

  // Get API for Weather for Historical Data
  getWeatherByCityForHistorical(cityName: any): Observable<any> {
    const url = API_URL + 'forecast?q=' + cityName + '&appid=' + API_KEY;
    return this.http.get<any>(url)
      .pipe(
        tap(_ => this.log('fetched Weather historical data')),
        catchError(this.handleError<any>('getWeatherByCityForHistorical'))
      );
  }
  
  /**
  * Handle Http operation that failed.
  * Let the app continue.
  * @param operation - name of the operation that failed
  * @param result - optional value to return as the observable result
  */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a LoginService message with the MessageService */
  private log(message: string) {
    console.log(`DashboardService: ${message}`)
  }
}
