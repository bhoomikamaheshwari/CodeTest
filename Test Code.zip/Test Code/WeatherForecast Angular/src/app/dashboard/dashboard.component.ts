import { Component, OnInit } from '@angular/core';
import { DashboardService } from '../services/dashboard.service';
import { LocalDataSource } from 'ng2-smart-table';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Label } from 'ng2-charts';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  selectedCity: any = "London";
  weatherDetails: any;
  weatherHistoricalData: any;
  currentDay: any;

  public barChartOptions: ChartOptions = {
    responsive: true,
    // We use these empty structures as placeholders for dynamic theming.
    scales: { xAxes: [{}], yAxes: [{}] },
    plugins: {
      datalabels: {
        anchor: 'end',
        align: 'end',
      }
    }
  };
  public barChartLabels: Label[];
  public barChartType: ChartType = 'bar';
  public barChartLegend = true;

  public barChartData: ChartDataSets[] = [];


  constructor(private dashboardService: DashboardService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getCurrentDate();
    this.getWeatherDataByCity();
  }


  // Method to fetch weather data for a city
  getWeatherDataByCity() {
    this.spinner.show();
    this.dashboardService.getWeatherByCity(this.selectedCity).subscribe(
      res => {
        if (res) {
          console.log(res, 'result');
          this.toastr.success("Weather Details Loaded Successfully");
          this.weatherDetails = res;
          this.spinner.hide();
        }
        else {
          console.log("No data found.");
          this.toastr.error("Weather Details Loaded Failed");
          this.spinner.hide();
        }
      }
    )
    this.getWeatherHistoricalDataByCity();
  }

  // Method to fetch weather historical data for a city
  getWeatherHistoricalDataByCity() {
    this.spinner.show();
    this.dashboardService.getWeatherByCityForHistorical(this.selectedCity).subscribe(
      res => {
        if (res) {
          console.log(res, 'result');
          this.weatherHistoricalData = res;
          this.spinner.hide();
          this.barChartLabels = [
            this.weatherHistoricalData.list[0].dt_txt,
            this.weatherHistoricalData.list[7].dt_txt,
            this.weatherHistoricalData.list[15].dt_txt,
            this.weatherHistoricalData.list[23].dt_txt,
            this.weatherHistoricalData.list[31].dt_txt
          ];

          this.barChartData = [
            { data: [this.weatherHistoricalData.list[0].main.temp, this.weatherHistoricalData.list[7].main.temp, this.weatherHistoricalData.list[15].main.temp, this.weatherHistoricalData.list[23].main.temp, this.weatherHistoricalData.list[31].main.temp], label: 'Temperature' },
            { data: [this.weatherHistoricalData.list[0].main.pressure, this.weatherHistoricalData.list[7].main.pressure, this.weatherHistoricalData.list[15].main.pressure, this.weatherHistoricalData.list[23].main.pressure, this.weatherHistoricalData.list[31].main.pressure], label: 'Pressure' },
            { data: [this.weatherHistoricalData.list[0].main.humidity, this.weatherHistoricalData.list[7].main.humidity, this.weatherHistoricalData.list[15].main.humidity, this.weatherHistoricalData.list[23].main.humidity, this.weatherHistoricalData.list[31].main.humidity], label: 'Humidity' }
          ];
        }
        else {
          console.log("No data found.");
          this.toastr.error("Historical Details Loaded Failed");
          this.spinner.hide();
        }
      }
    )
  }

  getCurrentDate() {
    var d = new Date();
    this.currentDay = d.toDateString();
  }
}
